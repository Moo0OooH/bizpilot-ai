/**
 * ============================================================
 * File: app/(dashboard)/dashboard/settings/page.tsx
 * Project: BizPilot AI
 * Description: Renders protected owner workspace settings.
 * Role: Keeps account, workspace, theme, and future billing/team controls separate from Quote Setup.
 * Author: MoOoH
 * Created: 2026-05-18
 * Last Updated: 2026-05-18
 * ============================================================
 */

import { redirect } from "next/navigation";

import {
  DashboardCard,
  disabledButtonClass,
  PageHeader,
  SectionHeader,
  StatusBadge,
} from "@/components/dashboard/dashboard-ui";
import { DashboardThemeSelector } from "@/components/dashboard/dashboard-theme";
import { getCurrentUser } from "@/server/services/auth.service";
import { getBusinessWorkspace } from "@/server/services/business.service";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/auth/sign-in");
  }

  const workspace = await getBusinessWorkspace({ userId: user.id });
  const activeBusiness = workspace.businesses[0];

  if (!activeBusiness) {
    redirect("/dashboard");
  }

  return (
    <main className="space-y-4">
      <PageHeader
        description="Workspace-level preferences for the owner dashboard. Quote forms, services, and public link settings stay in Quote Setup."
        eyebrow="Workspace"
        title="Settings"
      />

      <section className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="grid gap-4">
          <DashboardCard className="p-4">
            <SectionHeader description="Read-only account context for this MVP stage." title="Account" />
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div className="rounded-[14px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] p-3">
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[var(--dash-text-muted)]">Signed in as</p>
                <p className="mt-1 break-words text-sm font-semibold text-[var(--dash-text)]">{user.email ?? user.id}</p>
              </div>
              <div className="rounded-[14px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] p-3">
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[var(--dash-text-muted)]">Workspace</p>
                <p className="mt-1 text-sm font-semibold text-[var(--dash-text)]">{activeBusiness.name}</p>
              </div>
            </div>
          </DashboardCard>

          <DashboardCard className="p-4">
            <SectionHeader description="Hydration-safe dashboard theme. The initial value is resolved from a cookie on the server." title="Appearance" />
            <div className="mt-4 flex flex-wrap items-center gap-3">
              <DashboardThemeSelector />
              <p className="text-[13px] leading-5 text-[var(--dash-text-secondary)]">
                Keep dark mode as the default for the operational command-center feel. Light mode remains available for daytime use.
              </p>
            </div>
          </DashboardCard>

          <DashboardCard className="p-4">
            <SectionHeader description="These are intentionally not active in the MVP to avoid scope explosion." title="Future sections" />
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              {['Billing', 'Team members', 'Integrations'].map((item) => (
                <div className="rounded-[14px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] p-3" key={item}>
                  <div className="flex items-center justify-between gap-3">
                    <p className="text-sm font-semibold text-[var(--dash-text)]">{item}</p>
                    <StatusBadge>Future</StatusBadge>
                  </div>
                  <button className={`${disabledButtonClass} mt-3 w-full`} type="button">Not in MVP</button>
                </div>
              ))}
            </div>
          </DashboardCard>
        </div>

        <DashboardCard className="p-4 xl:sticky xl:top-24 xl:self-start" variant="priority">
          <SectionHeader title="MVP boundaries" />
          <div className="mt-4 grid gap-2 text-[13px] text-[var(--dash-text-secondary)]">
            <p>No auto-send.</p>
            <p>No invented pricing or availability.</p>
            <p>No booking, invoices, WhatsApp/SMS automation, or full CRM expansion in Phase 18A.</p>
          </div>
        </DashboardCard>
      </section>
    </main>
  );
}
