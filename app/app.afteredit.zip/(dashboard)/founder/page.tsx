/**
 * ============================================================
 * File: app/(dashboard)/founder/page.tsx
 * Project: BizPilot AI
 * Description: Founder Admin Console shell for Phase 18B.
 * Role: Provides a safe MVP visual surface for pilot tracking without exposing cross-tenant data yet.
 * Author: MoOoH
 * Created: 2026-05-18
 * Last Updated: 2026-05-18
 * ============================================================
 */

import Link from "next/link";
import { redirect } from "next/navigation";

import {
  buttonClass,
  DashboardCard,
  MetricCard,
  PageHeader,
  SectionHeader,
  StatusBadge,
} from "@/components/dashboard/dashboard-ui";
import { getCurrentUser } from "@/server/services/auth.service";
import { getBusinessWorkspace } from "@/server/services/business.service";

export const dynamic = "force-dynamic";

export default async function FounderConsolePage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/auth/sign-in");
  }

  const workspace = await getBusinessWorkspace({ userId: user.id });

  return (
    <main className="space-y-4">
      <PageHeader
        description="Phase 18B shell for founder-led pilot tracking. Connect founder-only policy before showing real cross-tenant data."
        eyebrow="Phase 18B"
        title="Founder Admin Console"
      />

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard detail="Connected to current accessible workspace only." label="Pilot businesses" tone="emerald" value={workspace.businesses.length} />
        <MetricCard detail="Requires founder policy before production use." label="Active quote links" tone="blue" value="TBD" />
        <MetricCard detail="Aggregate usage needs founder-safe service layer." label="Leads captured" tone="amber" value="TBD" />
        <MetricCard detail="Track payment readiness manually first." label="Payment ready" tone="neutral" value="TBD" />
      </section>

      <DashboardCard className="p-4" variant="elevated">
        <SectionHeader
          description="This table is intentionally limited until Phase 18B adds founder-only authorization and tenant-safe aggregation."
          title="Pilot tracking table"
        />
        <div className="mt-4 overflow-hidden rounded-[16px] border border-[var(--dash-border)]">
          <div className="hidden grid-cols-[minmax(180px,1fr)_120px_150px_150px_150px] border-b border-[var(--dash-border)] bg-[var(--dash-surface-muted)] px-3 py-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-[var(--dash-text-muted)] lg:grid">
            <span>Business</span>
            <span>Status</span>
            <span>Quote link</span>
            <span>Usage</span>
            <span>Next action</span>
          </div>
          {workspace.businesses.map((business) => (
            <div className="grid gap-3 border-b border-[var(--dash-border)] px-3 py-3 text-[13px] last:border-b-0 lg:grid-cols-[minmax(180px,1fr)_120px_150px_150px_150px] lg:items-center" key={business.id}>
              <span className="font-semibold text-[var(--dash-text)]">{business.name}</span>
              <StatusBadge tone="amber">Pilot</StatusBadge>
              <Link className={buttonClass} href={`/quote/${business.slug}`}>Open link</Link>
              <span className="text-[var(--dash-text-secondary)]">Owner scope only</span>
              <span className="text-[var(--dash-text-secondary)]">Add founder notes</span>
            </div>
          ))}
        </div>
      </DashboardCard>
    </main>
  );
}
