/**
 * ============================================================
 * File: app/(dashboard)/dashboard/page.tsx
 * Project: BizPilot AI
 * Description: Renders the protected Dashboard Overview workspace.
 * Role: Shows the Quote Recovery Command Center overview with magic moment, recovery metrics, queue preview, and setup readiness.
 * Related:
 * - app/(dashboard)/layout.tsx
 * - server/services/lead-conversion.service.ts
 * - server/services/business-configuration.service.ts
 * Author: MoOoH
 * Created: 2026-05-10
 * Last Updated: 2026-05-18
 * Change Log:
 * - 2026-05-10: Created Dashboard Overview as the default protected app page.
 * - 2026-05-11: Tightened dashboard alignment, card rhythm, and operational layout density.
 * - 2026-05-11: Upgraded overview into a quote recovery cockpit with priority actions.
 * - 2026-05-17: Added first-use Magic Moment sample lead state for pilot demos.
 * - 2026-05-18: Rebuilt overview to match the approved index.html command-center prototype.
 * ============================================================
 */

import Link from "next/link";
import { redirect } from "next/navigation";

import { CopyButton } from "@/components/dashboard/copy-button";
import {
  buttonClass,
  DashboardCard,
  EmptyState,
  LeadStatusBadge,
  MetricCard,
  PageHeader,
  primaryButtonClass,
  RightRailPanel,
  SectionHeader,
  StatusBadge,
} from "@/components/dashboard/dashboard-ui";
import { getCurrentUser } from "@/server/services/auth.service";
import { getBusinessConfigurationWorkspace } from "@/server/services/business-configuration.service";
import { getBusinessWorkspace } from "@/server/services/business.service";
import { getLeadConversionDesk } from "@/server/services/lead-conversion.service";

export const dynamic = "force-dynamic";

function formatDate(value: string | null): string {
  if (!value) {
    return "Not yet";
  }

  return new Intl.DateTimeFormat("en", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

function formatAge(value: string | null): string {
  if (!value) {
    return "Not yet";
  }

  const createdAt = new Date(value).getTime();
  const diffMinutes = Math.max(0, Math.round((Date.now() - createdAt) / 60000));

  if (diffMinutes < 60) {
    return `${Math.max(diffMinutes, 1)}m ago`;
  }

  const diffHours = Math.round(diffMinutes / 60);

  if (diffHours < 24) {
    return `${diffHours}h ago`;
  }

  return formatDate(value);
}

function riskLabel(value: string): string {
  if (value === "strong") {
    return "Low";
  }

  if (value === "needs_info") {
    return "Medium";
  }

  return "High";
}

function initials(value: string | null | undefined): string {
  if (!value) {
    return "L";
  }

  return value
    .split(" ")
    .map((part) => part.at(0))
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export default async function DashboardOverviewPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/auth/sign-in");
  }

  const workspace = await getBusinessWorkspace({
    userId: user.id,
  });
  const activeBusiness = workspace.businesses[0];

  if (!activeBusiness) {
    return (
      <main>
        <PageHeader
          description="No tenant business is available for this user yet."
          eyebrow="Overview"
          title="Dashboard Overview"
        />
      </main>
    );
  }

  const [configurationWorkspace, desk] = await Promise.all([
    getBusinessConfigurationWorkspace({
      business: activeBusiness,
    }),
    getLeadConversionDesk({
      actorUserId: user.id,
      business: activeBusiness,
    }),
  ]);

  const { readiness } = configurationWorkspace;
  const quotePath = `/quote/${activeBusiness.slug}`;
  const recentLeads = desk.leads.slice(0, 7);
  const newLeadCount = desk.leads.filter((item) => item.lead.status === "new").length;
  const overdueLeadCount = desk.leads.filter(
    (item) => item.lead.response_sla_state === "overdue",
  ).length;
  const missingInfoCount = desk.leads.filter(
    (item) => item.score.quality_level === "needs_info",
  ).length;
  const aiDraftReadyCount = desk.leads.filter(
    (item) => item.lead.status === "new" || item.lead.status === "follow_up_needed",
  ).length;
  const actionCounts = {
    askInfo: desk.todaysActions.filter((action) => action.action_type === "ask_info").length,
    followUp: desk.todaysActions.filter((action) => action.action_type === "follow_up").length,
    reply: desk.todaysActions.filter((action) => action.action_type === "reply").length,
  };
  const repliesNeedingAttention = actionCounts.reply + actionCounts.followUp + overdueLeadCount;
  const readinessPercent = Math.round(
    (readiness.completed / Math.max(readiness.total, 1)) * 100,
  );
  const missingReadinessItems = readiness.items.filter((item) => !item.complete);
  const featuredLead =
    desk.leads.find((item) => item.lead.response_sla_state === "overdue") ??
    desk.leads.find((item) => item.lead.status === "new") ??
    desk.leads[0];
  const featuredLeadName = featuredLead?.lead.customer_name ?? "Sarah M.";
  const featuredLeadService = featuredLead?.lead.service_type ?? "Move-out cleaning";
  const featuredLeadArea = featuredLead?.lead.city_or_service_area ?? "Plateau";
  const featuredLeadAge = featuredLead ? formatAge(featuredLead.lead.created_at) : "22m ago";
  const featuredNextAction =
    featuredLead?.recommendedAction ??
    "Ask for apartment size, preferred date, and access details before giving an estimate range.";
  const quoteLinkPlacementProgress =
    readiness.items.find((item) => item.label.toLowerCase().includes("public"))?.complete ??
    false;

  return (
    <main className="space-y-4">
      <PageHeader
        actions={
          <>
            <Link className={buttonClass} href={quotePath}>
              Preview Quote Page
            </Link>
            <Link className={primaryButtonClass} href="/dashboard/leads">
              Open Lead Desk
            </Link>
          </>
        }
        description="See what needs attention, which leads are at risk, and what to do next."
        eyebrow="Overview"
        title="Dashboard Overview"
      />

      <DashboardCard
        className="overflow-hidden border-[rgba(23,212,146,0.22)] p-5 shadow-[0_22px_70px_rgba(2,6,23,0.18)] md:p-6"
        variant="priority"
      >
        <div className="grid gap-5 xl:grid-cols-[minmax(0,1.22fr)_minmax(19rem,0.78fr)] xl:items-stretch">
          <div className="min-w-0">
            <StatusBadge tone="emerald">Phase 18A - Pilot readiness</StatusBadge>
            <h2 className="mt-4 max-w-3xl text-[32px] font-semibold leading-[1.04] tracking-[-0.055em] text-[var(--dash-text)] sm:text-[40px] lg:text-[44px]">
              {Math.max(repliesNeedingAttention, newLeadCount, 1)} quote requests need attention today.
            </h2>
            <p className="mt-4 max-w-3xl text-[15px] leading-7 text-[var(--dash-text-secondary)]">
              Reply while the customer is still comparing options. BizPilot surfaces urgent leads,
              drafts the response, and keeps the owner in control.
            </p>
            <div className="mt-5 flex flex-wrap gap-2.5">
              <Link className={primaryButtonClass} href={featuredLead ? `/dashboard/leads/${featuredLead.lead.id}` : "/dashboard/leads"}>
                Review urgent lead
              </Link>
              <Link className={buttonClass} href="/dashboard/leads">
                Open Lead Recovery Queue
              </Link>
            </div>
          </div>

          <div className="grid gap-3 rounded-[18px] border border-[var(--dash-border)] bg-[var(--dash-surface-elevated)] p-4">
            <div className="flex min-w-0 items-center gap-3">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-[15px] bg-[var(--dash-primary)] text-sm font-bold text-[#03130c]">
                {initials(featuredLeadName)}
              </span>
              <span className="min-w-0">
                <span className="block truncate text-[16px] font-semibold text-[var(--dash-text)]">
                  {featuredLeadName}
                </span>
                <span className="mt-1 block text-[13px] leading-5 text-[var(--dash-text-secondary)]">
                  {featuredLeadService} - {featuredLeadArea} - {featuredLeadAge}
                </span>
              </span>
            </div>
            <div className="grid gap-2">
              <StatusBadge tone={overdueLeadCount > 0 ? "red" : "amber"}>At risk soon</StatusBadge>
              <StatusBadge tone="emerald">AI draft ready</StatusBadge>
              <StatusBadge tone={missingInfoCount > 0 ? "amber" : "neutral"}>
                {missingInfoCount > 0 ? "Missing information" : "Ready to review"}
              </StatusBadge>
            </div>
            <div className="rounded-[15px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] p-3 text-[13px] leading-6 text-[var(--dash-text-secondary)]">
              <span className="font-semibold text-[var(--dash-text)]">Suggested next action:</span>{" "}
              {featuredNextAction}
            </div>
          </div>
        </div>
      </DashboardCard>

      <section className="grid min-w-0 gap-3.5 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          detail="Last 7 days and pilot activity."
          label="New quote requests"
          tone="emerald"
          value={desk.recoveryProof.quoteRequestsCaptured}
        />
        <MetricCard
          detail="Waiting for owner response."
          label="Needs reply"
          tone={repliesNeedingAttention > 0 ? "amber" : "neutral"}
          value={repliesNeedingAttention}
        />
        <MetricCard
          detail="No reply after the safe response window."
          label="At risk leads"
          tone={overdueLeadCount > 0 ? "red" : "neutral"}
          value={overdueLeadCount}
        />
        <MetricCard
          detail="Review before using. Nothing sends automatically."
          label="AI drafts ready"
          tone="blue"
          value={aiDraftReadyCount}
        />
      </section>

      <section className="grid min-w-0 items-start gap-4 xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="min-w-0 space-y-4">
          <DashboardCard className="min-w-0 p-4" variant="elevated">
            <SectionHeader
              action={
                <Link className="text-[13px] font-semibold text-[var(--dash-primary)]" href="/dashboard/leads">
                  View all leads
                </Link>
              }
              description="Newest requests, risk, and next action. Scroll inside the queue without losing the header."
              title="Lead Recovery Queue"
            />
            <div className="mt-4 min-w-0 overflow-hidden rounded-[16px] border border-[var(--dash-border)]">
              <div className="max-h-[440px] overflow-auto">
                <div className="sticky top-0 z-10 hidden min-w-[980px] grid-cols-[minmax(210px,1.25fr)_130px_130px_120px_100px_minmax(230px,1fr)] border-b border-[var(--dash-border)] bg-[var(--dash-surface-muted)] px-4 py-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-[var(--dash-text-muted)] xl:grid">
                  <span>Customer</span>
                  <span>Service</span>
                  <span>Location</span>
                  <span>Status</span>
                  <span>Age</span>
                  <span>Next action</span>
                </div>

                {recentLeads.length > 0 ? (
                  <div className="min-w-0 xl:min-w-[980px]">
                    {recentLeads.map((item) => (
                      <Link
                        className="grid gap-3 border-b border-[var(--dash-border)] px-4 py-3 text-[13px] transition last:border-b-0 hover:bg-[var(--dash-primary-soft)] xl:min-h-[72px] xl:grid-cols-[minmax(210px,1.25fr)_130px_130px_120px_100px_minmax(230px,1fr)] xl:items-center"
                        href={`/dashboard/leads/${item.lead.id}`}
                        key={item.lead.id}
                      >
                        <span className="min-w-0">
                          <span className="block truncate font-semibold text-[var(--dash-text)]">
                            {item.lead.customer_name ?? "Unnamed lead"}
                          </span>
                          <span className="mt-1 block break-all text-[13px] leading-5 text-[var(--dash-text-muted)]">
                            {item.lead.customer_contact ?? "No contact captured"}
                          </span>
                        </span>
                        <span className="text-[var(--dash-text-secondary)]">
                          {item.lead.service_type ?? "Service not set"}
                        </span>
                        <span className="text-[var(--dash-text-secondary)]">
                          {item.lead.city_or_service_area ?? item.lead.source_channel ?? "Quote link"}
                        </span>
                        <span className="flex flex-wrap gap-1.5">
                          <StatusBadge
                            tone={
                              item.lead.response_sla_state === "overdue"
                                ? "red"
                                : item.score.quality_level === "needs_info"
                                  ? "amber"
                                  : "emerald"
                            }
                          >
                            {item.lead.response_sla_state === "overdue"
                              ? "At risk"
                              : riskLabel(item.score.quality_level)}
                          </StatusBadge>
                          <LeadStatusBadge value={item.lead.status} />
                        </span>
                        <span className="text-[var(--dash-text-muted)]">
                          {formatAge(item.lead.created_at)}
                        </span>
                        <span className="rounded-[12px] bg-[var(--dash-primary-soft)] px-3 py-2 leading-5 text-[var(--dash-text-secondary)]">
                          {item.recommendedAction}
                        </span>
                      </Link>
                    ))}
                  </div>
                ) : (
                  <div className="p-4">
                    <EmptyState
                      action={<CopyButton label="Copy quote link" value={quotePath} />}
                      title="Your quote recovery desk is ready."
                    >
                      Share your quote link to start capturing cleaning requests. The first real lead will appear here with AI summary, missing info, and next action.
                    </EmptyState>
                  </div>
                )}
              </div>
            </div>
          </DashboardCard>

          <DashboardCard className="p-4" variant="elevated">
            <SectionHeader
              description="Operational timeline for quote recovery and owner actions."
              title="Recent Activity"
            />
            <div className="mt-4 grid gap-3">
              {recentLeads.length > 0 ? (
                recentLeads.slice(0, 4).map((item) => (
                  <Link
                    className="grid grid-cols-[2rem_minmax(0,1fr)_auto] gap-3 rounded-[14px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] px-3 py-3 transition hover:bg-[var(--dash-primary-soft)]"
                    href={`/dashboard/leads/${item.lead.id}`}
                    key={item.lead.id}
                  >
                    <span className="flex h-8 w-8 items-center justify-center rounded-[10px] bg-[var(--dash-primary-soft)] text-xs font-semibold text-[var(--dash-primary)]">
                      AI
                    </span>
                    <span className="min-w-0">
                      <span className="block text-[13px] font-semibold text-[var(--dash-text)]">
                        AI summary ready for {item.lead.customer_name ?? "new lead"}
                      </span>
                      <span className="mt-1 block truncate text-[12px] text-[var(--dash-text-secondary)]">
                        {item.primaryIssue || item.recommendedAction}
                      </span>
                    </span>
                    <span className="text-[12px] text-[var(--dash-text-muted)]">
                      {formatAge(item.lead.created_at)}
                    </span>
                  </Link>
                ))
              ) : (
                <EmptyState title="No recent activity yet.">
                  New quote requests, AI summaries, review actions, and quote link copies will appear here.
                </EmptyState>
              )}
            </div>
          </DashboardCard>
        </div>

        <aside className="min-w-0 space-y-3.5 xl:sticky xl:top-[84px]">
          <RightRailPanel variant="priority">
            <SectionHeader
              action={<StatusBadge tone={missingReadinessItems.length === 0 ? "emerald" : "amber"}>{missingReadinessItems.length === 0 ? "Ready" : "Incomplete"}</StatusBadge>}
              description="Your public quote page readiness for pilot calls."
              title="Quote link readiness"
            />
            <div className="mt-4 grid gap-3">
              <div className="grid grid-cols-[3.5rem_minmax(0,1fr)] gap-3 rounded-[14px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] p-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-full border-[4px] border-[var(--dash-primary)]/30 text-[13px] font-semibold text-[var(--dash-text)]">
                  {readinessPercent}%
                </div>
                <div className="min-w-0">
                  <p className="text-[13px] font-semibold text-[var(--dash-text)]">
                    {missingReadinessItems.length === 0 ? "Active and ready" : `${missingReadinessItems.length} tasks left`}
                  </p>
                  <p className="mt-1 text-[12px] leading-5 text-[var(--dash-text-secondary)]">
                    Public quote link is live and shareable.
                  </p>
                </div>
              </div>
              <div className="grid gap-2 text-[13px]">
                {readiness.items.slice(0, 5).map((item) => (
                  <div
                    className="flex items-start justify-between gap-3 border-b border-[var(--dash-border)] pb-2 last:border-b-0 last:pb-0"
                    key={item.label}
                  >
                    <span className="text-[var(--dash-text-secondary)]">{item.label}</span>
                    <StatusBadge tone={item.complete ? "emerald" : "amber"}>
                      {item.complete ? "Done" : "Needed"}
                    </StatusBadge>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <CopyButton label="Copy link" value={quotePath} />
                <Link className={buttonClass} href="/dashboard/configuration">
                  Finish setup
                </Link>
              </div>
            </div>
          </RightRailPanel>

          <RightRailPanel>
            <SectionHeader
              description={`${actionCounts.reply + actionCounts.askInfo + actionCounts.followUp} items`}
              title="Today's recovery queue"
            />
            <div className="mt-3 grid gap-2">
              {[
                ["Reply needed", `${actionCounts.reply} leads waiting`, actionCounts.reply],
                ["Missing info", `${actionCounts.askInfo} lead needs details`, actionCounts.askInfo],
                ["Follow-up due", `${actionCounts.followUp} follow-up due today`, actionCounts.followUp],
              ].map(([title, detail, value]) => (
                <Link
                  className="grid min-h-[54px] grid-cols-[2rem_minmax(0,1fr)_auto] items-center gap-2.5 rounded-[13px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] px-3 py-2 text-[13px] transition hover:bg-[var(--dash-primary-soft)]"
                  href="/dashboard/leads"
                  key={title}
                >
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[var(--dash-primary-soft)] text-[13px] font-semibold text-[var(--dash-primary)]">
                    {value}
                  </span>
                  <span className="min-w-0">
                    <span className="block font-semibold text-[var(--dash-text)]">{title}</span>
                    <span className="mt-0.5 block truncate text-[12px] text-[var(--dash-text-secondary)]">
                      {detail}
                    </span>
                  </span>
                  <span className="text-[var(--dash-text-muted)]">&gt;</span>
                </Link>
              ))}
            </div>
          </RightRailPanel>

          <RightRailPanel>
            <SectionHeader title="AI stays under your control" />
            <p className="mt-3 text-[13px] leading-6 text-[var(--dash-text-secondary)]">
              BizPilot drafts replies, summaries, and follow-ups. Nothing is sent automatically.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <StatusBadge tone="emerald">No auto-send</StatusBadge>
              <StatusBadge tone="emerald">No invented pricing</StatusBadge>
              <StatusBadge tone="blue">Owner reviewed</StatusBadge>
            </div>
          </RightRailPanel>

          <RightRailPanel>
            <SectionHeader title="Owner routine suggestion" />
            <div className="mt-3 grid gap-2 text-[13px]">
              {[
                ["1", "Review at-risk leads", overdueLeadCount > 0 ? "Start with overdue quote requests." : "Check new requests first."],
                ["2", "Copy AI replies", "Edit before sending manually."],
                ["3", "Follow up unanswered requests", "Use owner-approved drafts."],
              ].map(([step, title, detail]) => (
                <div className="grid grid-cols-[1.75rem_minmax(0,1fr)] gap-2 rounded-[12px] bg-[var(--dash-surface-muted)] p-2.5" key={step}>
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[var(--dash-primary-soft)] text-xs font-semibold text-[var(--dash-primary)]">
                    {step}
                  </span>
                  <span>
                    <span className="block font-semibold text-[var(--dash-text)]">{title}</span>
                    <span className="mt-0.5 block text-[12px] leading-5 text-[var(--dash-text-secondary)]">
                      {detail}
                    </span>
                  </span>
                </div>
              ))}
            </div>
          </RightRailPanel>

          <RightRailPanel>
            <SectionHeader
              action={<StatusBadge tone="emerald">Active</StatusBadge>}
              description="Share this link wherever customers ask for quotes."
              title="Public quote link"
            />
            <p className="mt-3 break-all rounded-[13px] bg-[var(--dash-primary-soft)] px-3 py-2.5 text-[13px] font-semibold text-[var(--dash-primary)]">
              {quotePath}
            </p>
            <div className="mt-3 text-[12px] leading-5 text-[var(--dash-text-secondary)]">
              {quoteLinkPlacementProgress
                ? "Placed in 1 of 2 recommended channels"
                : "Not placed in recommended channels yet"}
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[var(--dash-surface-muted)]">
                <div
                  className="h-full rounded-full bg-[var(--dash-primary)]"
                  style={{ width: quoteLinkPlacementProgress ? "50%" : "0%" }}
                />
              </div>
            </div>
          </RightRailPanel>
        </aside>
      </section>
    </main>
  );
}
