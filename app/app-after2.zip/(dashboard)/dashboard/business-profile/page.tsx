/**
 * ============================================================
 * File: app/(dashboard)/dashboard/business-profile/page.tsx
 * Project: BizPilot AI
 * Description: Renders the protected Business Profile workspace.
 * Role: Keeps business identity and operating context separate from Quote Setup.
 * Related:
 * - app/(dashboard)/dashboard/configuration/page.tsx
 * - server/actions/business-configuration.actions.ts
 * Author: MoOoH
 * Created: 2026-05-18
 * Last Updated: 2026-05-18
 * ============================================================
 */

import Link from "next/link";
import { redirect } from "next/navigation";

import {
  buttonClass,
  DashboardCard,
  inputClass,
  labelClass,
  PageHeader,
  primaryButtonClass,
  SectionHeader,
  textareaClass,
} from "@/components/dashboard/dashboard-ui";
import { saveBusinessConfigurationAction } from "@/server/actions/business-configuration.actions";
import { getCurrentUser } from "@/server/services/auth.service";
import { getBusinessConfigurationWorkspace } from "@/server/services/business-configuration.service";
import { getBusinessWorkspace } from "@/server/services/business.service";

export const dynamic = "force-dynamic";

type BusinessProfilePageProps = Readonly<{
  searchParams?: Promise<{
    error?: string;
    notice?: string;
  }>;
}>;

function serviceAreasToText(
  areas: Awaited<
    ReturnType<typeof getBusinessConfigurationWorkspace>
  >["configuration"]["serviceAreas"],
): string {
  return areas.map((area) => area.name).join("\n");
}

function servicesToText(
  services: Awaited<
    ReturnType<typeof getBusinessConfigurationWorkspace>
  >["configuration"]["services"],
): string {
  return services
    .map((service) =>
      service.description
        ? `${service.name} | ${service.description}`
        : service.name,
    )
    .join("\n");
}

function faqsToText(
  faqs: Awaited<
    ReturnType<typeof getBusinessConfigurationWorkspace>
  >["configuration"]["faqs"],
): string {
  return faqs.map((faq) => `${faq.question} | ${faq.answer}`).join("\n");
}

export default async function BusinessProfilePage({
  searchParams,
}: BusinessProfilePageProps) {
  const [params, user] = await Promise.all([searchParams, getCurrentUser()]);

  if (!user) {
    redirect("/auth/sign-in");
  }

  const workspace = await getBusinessWorkspace({ userId: user.id });
  const activeBusiness = workspace.businesses[0];

  if (!activeBusiness) {
    redirect("/dashboard");
  }

  const configurationWorkspace = await getBusinessConfigurationWorkspace({
    business: activeBusiness,
  });
  const { cleaningTemplate, configuration } = configurationWorkspace;
  const quotePath = `/quote/${activeBusiness.slug}`;
  const primaryColor = configuration.branding?.primary_color ?? "#18181b";
  const accentColor = configuration.branding?.accent_color ?? "#0f766e";
  const consentNotice =
    configuration.consentSettings?.consent_notice ??
    "By submitting this request, you agree that your information will be shared with this business to respond to your quote request. BizPilot may help prepare internal AI drafts, but the business reviews messages before sending.";
  const privacyMode = configuration.privacySettings?.privacy_mode ?? "standard";
  const retainLeadsDays = configuration.privacySettings?.retain_leads_days ?? 365;

  return (
    <main className="space-y-4">
      <PageHeader
        actions={
          <>
            <Link className={buttonClass} href="/dashboard/configuration">
              Open Quote Setup
            </Link>
            <Link className={primaryButtonClass} href={quotePath}>
              Preview Quote Page
            </Link>
          </>
        }
        description="Manage the business identity and operating context used across the dashboard, public quote page, and AI draft guidance."
        eyebrow="Business"
        title="Business Profile"
      />

      {params?.notice ? (
        <p className="rounded-[14px] border border-emerald-300/35 bg-emerald-500/12 p-3 text-xs font-medium text-emerald-700 dark:text-emerald-200">
          {params.notice}
        </p>
      ) : null}

      {params?.error ? (
        <p className="rounded-[14px] border border-red-300/35 bg-red-500/12 p-3 text-xs font-medium text-red-700 dark:text-red-200">
          {params.error}
        </p>
      ) : null}

      <form action={saveBusinessConfigurationAction} className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_320px]">
        <input name="businessId" type="hidden" value={activeBusiness.id} />
        <input name="templateId" type="hidden" value={cleaningTemplate.template.id} />
        <input name="primaryColor" type="hidden" value={primaryColor} />
        <input name="consentNotice" type="hidden" value={consentNotice} />
        <input name="privacyMode" type="hidden" value={privacyMode} />
        <input name="retainLeadsDays" type="hidden" value={retainLeadsDays} />
        <input name="services" type="hidden" value={servicesToText(configuration.services)} />
        <input name="faqs" type="hidden" value={faqsToText(configuration.faqs)} />
        {configuration.consentSettings?.privacy_contact_email ? (
          <input
            name="privacyContactEmail"
            type="hidden"
            value={configuration.consentSettings.privacy_contact_email}
          />
        ) : null}
        {configuration.consentSettings?.ai_disclosure_enabled ?? true ? (
          <input name="aiDisclosureEnabled" type="hidden" value="on" />
        ) : null}
        {cleaningTemplate.fields.map((field) => (
          <span hidden key={field.field_key}>
            <input name="templateFieldKeys" type="hidden" value={field.field_key} />
            <input name={`fieldLabel:${field.field_key}`} type="hidden" value={field.label} />
            <input name={`fieldHelp:${field.field_key}`} type="hidden" value={field.help_text ?? ""} />
            <input name={`fieldSort:${field.field_key}`} type="hidden" value={field.sort_order} />
            {field.is_required ? (
              <input name={`fieldRequired:${field.field_key}`} type="hidden" value="on" />
            ) : null}
            {field.is_hidden ? (
              <input name={`fieldHidden:${field.field_key}`} type="hidden" value="on" />
            ) : null}
          </span>
        ))}

        <div className="grid gap-4">
          <DashboardCard className="p-4" variant="elevated">
            <SectionHeader
              description="This is the owner-facing identity. Quote Setup controls the actual public form and link."
              title="Business identity"
            />
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <label className={labelClass}>
                Business name
                <input className={inputClass} defaultValue={activeBusiness.name} name="businessName" required type="text" />
              </label>
              <label className={labelClass}>
                Public slug
                <input className={inputClass} defaultValue={activeBusiness.slug} name="businessSlug" required type="text" />
              </label>
              <label className={labelClass}>
                Logo URL
                <input className={inputClass} defaultValue={configuration.branding?.logo_url ?? ""} name="logoUrl" type="url" />
              </label>
              <label className={labelClass}>
                Accent color
                <input className={`${inputClass} h-11`} defaultValue={accentColor} name="accentColor" type="color" />
              </label>
            </div>
          </DashboardCard>

          <DashboardCard className="p-4">
            <SectionHeader
              description="Used for owner context and public quote setup. Keep AI guardrails and FAQ details in Quote Setup."
              title="Operating context"
            />
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <label className={`${labelClass} sm:col-span-2`}>
                Service areas
                <textarea
                  className={`${textareaClass} min-h-28`}
                  defaultValue={serviceAreasToText(configuration.serviceAreas)}
                  name="serviceAreas"
                  placeholder="Montreal\nLaval\nLongueuil"
                />
              </label>
              <label className={`${labelClass} sm:col-span-2`}>
                Custom quote template name
                <textarea
                  className={`${textareaClass} min-h-32`}
                  defaultValue={configuration.templateSettings?.custom_name ?? ""}
                  name="customTemplateName"
                  placeholder="Cleaning quote intake template"
                />
              </label>
            </div>
          </DashboardCard>
        </div>

        <aside className="space-y-4 xl:sticky xl:top-24 xl:self-start">
          <DashboardCard className="p-4" variant="priority">
            <SectionHeader title="Profile readiness" />
            <div className="mt-4 grid gap-2 text-[13px] text-[var(--dash-text-secondary)]">
              <p className="rounded-[12px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] p-3">
                Business identity is separate from Quote Setup so future verticals do not pollute the quote form configuration.
              </p>
              <p className="rounded-[12px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] p-3">
                Current public quote link: <span className="font-semibold text-[var(--dash-text)]">{quotePath}</span>
              </p>
            </div>
          </DashboardCard>

          <button className={`${primaryButtonClass} w-full`} type="submit">
            Save Business Profile
          </button>
        </aside>
      </form>
    </main>
  );
}
