"use client";
// File: components/dashboard/dashboard-theme.tsx
// Hydration-safe dashboard light/dark theme. Server resolves the initial value
// from a cookie and passes it as a prop, so first client render matches SSR.
// Last Updated: 2026-05-18

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

type T = "dark" | "light";
type Ctx = Readonly<{ setTheme: (v: T) => void; theme: T }>;

export const DASHBOARD_THEME_COOKIE = "bizpilot-dashboard-theme";
const KEY = "bizpilot-dashboard-theme";
const MAX_AGE = 60 * 60 * 24 * 365;

const ThemeCtx = createContext<Ctx | null>(null);

function persist(v: T): void {
  if (typeof document !== "undefined") {
    document.cookie = `${DASHBOARD_THEME_COOKIE}=${v}; path=/; max-age=${MAX_AGE}; samesite=lax`;
  }
  if (typeof window !== "undefined") {
    window.localStorage.setItem(KEY, v);
  }
}

export function DashboardThemeFrame({
  children,
  initialTheme = "dark",
}: Readonly<{ children: ReactNode; initialTheme?: T }>) {
  const [theme, setTheme] = useState<T>(initialTheme);

  useEffect(() => {
    persist(initialTheme);
  }, [initialTheme]);

  const value = useMemo<Ctx>(
    () => ({
      setTheme: (next) => {
        setTheme(next);
        persist(next);
      },
      theme,
    }),
    [theme],
  );

  const cls = theme === "dark" ? "biz-dashboard-dark" : "biz-dashboard-light";

  return (
    <ThemeCtx.Provider value={value}>
      <main
        className={`${cls} dashboard-frame min-h-screen transition-colors lg:grid lg:grid-cols-[260px_minmax(0,1fr)]`}
      >
        {children}
      </main>
    </ThemeCtx.Provider>
  );
}

export function DashboardThemeSelector() {
  const ctx = useContext(ThemeCtx);
  if (!ctx) {
    throw new Error(
      "DashboardThemeSelector must be used inside DashboardThemeFrame.",
    );
  }
  const { setTheme, theme } = ctx;

  return (
    <div
      aria-label="Dashboard theme"
      className="hidden h-8 rounded-[9px] border border-[var(--dash-border-strong)] bg-[var(--dash-surface-elevated)] p-1 text-xs font-medium shadow-sm sm:inline-flex"
      role="group"
    >
      {(["light", "dark"] as const).map((opt) => (
        <button
          aria-pressed={theme === opt}
          className={
            theme === opt
              ? "rounded-md bg-[var(--dash-primary)] px-2.5 text-white"
              : "rounded-md px-2.5 text-[var(--dash-text-secondary)] transition hover:bg-[var(--dash-surface-muted)] hover:text-[var(--dash-text)]"
          }
          key={opt}
          onClick={() => setTheme(opt)}
          type="button"
        >
          {opt === "light" ? "Light" : "Dark"}
        </button>
      ))}
    </div>
  );
}
// padding to fill the windows file-allocation tail; ignore.
// padding to fill the windows file-allocation tail; ignore.
// padding to fill the windows file-allocation tail; ignore.
