"use client";

/**
 * File: components/dashboard/dashboard-theme.tsx
 * Project: BizPilot AI
 * Role: Hydration-safe dashboard theme provider and selector.
 * Last Updated: 2026-05-18
 */

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

type DashboardTheme = "dark" | "light";
type ThemeContextValue = Readonly<{
  setTheme: (nextTheme: DashboardTheme) => void;
  theme: DashboardTheme;
}>;

export const DASHBOARD_THEME_COOKIE = "bizpilot-dashboard-theme";
const STORAGE_KEY = "bizpilot-dashboard-theme";
const MAX_AGE = 60 * 60 * 24 * 365;

const ThemeContext = createContext<ThemeContextValue | null>(null);

function persistTheme(nextTheme: DashboardTheme): void {
  document.cookie = `${DASHBOARD_THEME_COOKIE}=${nextTheme}; path=/; max-age=${MAX_AGE}; samesite=lax`;
  window.localStorage.setItem(STORAGE_KEY, nextTheme);
}

export function DashboardThemeFrame({
  children,
  initialTheme = "dark",
}: Readonly<{ children: ReactNode; initialTheme?: DashboardTheme }>) {
  const [theme, setThemeState] = useState<DashboardTheme>(initialTheme);

  useEffect(() => {
    persistTheme(initialTheme);
  }, [initialTheme]);

  const value = useMemo<ThemeContextValue>(
    () => ({
      setTheme: (nextTheme) => {
        setThemeState(nextTheme);
        persistTheme(nextTheme);
      },
      theme,
    }),
    [theme],
  );

  const themeClass = theme === "dark" ? "biz-dashboard-dark" : "biz-dashboard-light";

  return (
    <ThemeContext.Provider value={value}>
      <main
        className={`${themeClass} dashboard-frame min-h-screen transition-colors lg:grid lg:grid-cols-[260px_minmax(0,1fr)]`}
      >
        {children}
      </main>
    </ThemeContext.Provider>
  );
}

export function DashboardThemeSelector() {
  const context = useContext(ThemeContext);

  if (!context) {
    throw new Error("DashboardThemeSelector must be used inside DashboardThemeFrame.");
  }

  const { setTheme, theme } = context;

  return (
    <div
      aria-label="Dashboard theme"
      className="hidden h-9 rounded-[11px] border border-[var(--dash-border-strong)] bg-[var(--dash-surface-elevated)] p-1 text-xs font-semibold shadow-sm sm:inline-flex"
      role="group"
    >
      {(["light", "dark"] as const).map((option) => (
        <button
          aria-pressed={theme === option}
          className={
            theme === option
              ? "rounded-[8px] bg-[var(--dash-primary)] px-2.5 text-[#03130c]"
              : "rounded-[8px] px-2.5 text-[var(--dash-text-secondary)] transition hover:bg-[var(--dash-surface-muted)] hover:text-[var(--dash-text)]"
          }
          key={option}
          onClick={() => setTheme(option)}
          type="button"
        >
          {option === "light" ? "Light" : "Dark"}
        </button>
      ))}
    </div>
  );
}
