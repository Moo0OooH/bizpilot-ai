"use client";

/**
 * ============================================================
 * File: components/dashboard/lead-workspace-queue.tsx
 * Project: BizPilot AI
 * Description: Renders the interactive Lead Recovery Queue table.
 * Role: Provides filtering, search, sorting, tenant lead rows, and first-use sample guidance.
 * Related:
 * - app/(dashboard)/dashboard/leads/page.tsx
 * - components/dashboard/dashboard-ui.tsx
 * Author: MoOoH
 * Created: 2026-05-11
 * Last Updated: 2026-05-18
 * Change Log:
 * - 2026-05-11: Created the interactive lead queue.
 * - 2026-05-17: Added Magic Moment empty state aligned to the pilot demo flow.
 * - 2026-05-18: Finalized Phase 18A queue filters, mobile cards, and operational density.
 * ============================================================
 */

import Link from "next/link";
import { useMemo, useState } from "react";

import { CopyButton } from "@/components/dashboard/copy-button";
import {
  buttonClass,
  EmptyState,
  inputClass,
  LeadQualityBadge,
  LeadStatusBadge,
  ResponseSlaBadge,
  StatusBadge,
} from "@/components/dashboard/dashboard-ui";
import type { LeadDeskItem } from "@/server/services/lead-conversion.service";

type LeadFilter =
  | "all"
  | "needs_reply"
  | "at_risk"
  | "missing_info"
  | "ai_ready"
  | "reviewed"
  | "won"
  | "lost";

type LeadSort = "newest" | "oldest" | "most_urgent";

type LeadWorkspaceQueueProps = Readonly<{
  leads: LeadDeskItem[];
  quotePath: string;
}>;

const filters: ReadonlyArray<{ label: string; value: LeadFilter }> = [
  { label: "All", value: "all" },
  { label: "Needs Reply", value: "needs_reply" },
  { label: "At Risk", value: "at_risk" },
  { label: "Missing Info", value: "missing_info" },
  { label: "AI Ready", value: "ai_ready" },
  { label: "Reviewed", value: "reviewed" },
  { label: "Won", value: "won" },
  { label: "Lost", value: "lost" },
];

function formatDate(value: string | null): string {
  if (!value) {
    return "Not yet";
  }

  return new Intl.DateTimeFormat("en", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

function createdTimestamp(item: LeadDeskItem): number {
  return item.lead.created_at ? new Date(item.lead.created_at).getTime() : 0;
}

function urgencyScore(item: LeadDeskItem): number {
  if (item.lead.response_sla_state === "overdue") {
    return 100;
  }

  if (item.lead.status === "new") {
    return 80;
  }

  if (item.lead.status === "follow_up_needed") {
    return 70;
  }

  if (item.score.quality_level === "needs_info") {
    return 60;
  }

  return 20;
}

function matchesFilter(item: LeadDeskItem, filter: LeadFilter): boolean {
  if (filter === "all") {
    return true;
  }

  if (filter === "needs_reply") {
    return item.lead.status === "new" || item.lead.response_sla_state === "new";
  }

  if (filter === "at_risk") {
    return item.lead.response_sla_state === "overdue";
  }

  if (filter === "missing_info") {
    return item.score.quality_level === "needs_info";
  }

  if (filter === "ai_ready") {
    return Boolean(item.lead.first_reply_copied_at) || item.lead.status === "replied";
  }

  if (filter === "won") {
    return item.lead.status === "booked" || item.lead.manual_outcome === "booked";
  }

  if (filter === "lost") {
    return item.lead.status === "lost" || item.lead.manual_outcome === "lost";
  }

  return item.lead.status === filter;
}

function matchesSearch(item: LeadDeskItem, search: string): boolean {
  const normalizedSearch = search.trim().toLowerCase();

  if (normalizedSearch.length === 0) {
    return true;
  }

  return [
    item.lead.customer_name,
    item.lead.customer_contact,
    item.lead.service_type,
    item.lead.source_channel,
    item.lead.city_or_service_area,
    item.recommendedAction,
    item.primaryIssue,
  ]
    .filter((value): value is string => Boolean(value))
    .some((value) => value.toLowerCase().includes(normalizedSearch));
}

function sortLeads(leads: LeadDeskItem[], sort: LeadSort): LeadDeskItem[] {
  return [...leads].sort((left, right) => {
    if (sort === "oldest") {
      return createdTimestamp(left) - createdTimestamp(right);
    }

    if (sort === "most_urgent") {
      const urgencyDifference = urgencyScore(right) - urgencyScore(left);
      return urgencyDifference !== 0
        ? urgencyDifference
        : createdTimestamp(right) - createdTimestamp(left);
    }

    return createdTimestamp(right) - createdTimestamp(left);
  });
}

function SampleLeadEmptyState({ quotePath }: Readonly<{ quotePath: string }>) {
  return (
    <div className="grid gap-4 rounded-[18px] border border-dashed border-[rgba(23,212,146,0.28)] bg-[var(--dash-primary-soft)] p-4">
      <div className="flex flex-wrap items-center gap-2">
        <StatusBadge tone="amber">Sample lead</StatusBadge>
        <StatusBadge tone="red">Reply needed</StatusBadge>
        <StatusBadge tone="emerald">AI draft ready</StatusBadge>
      </div>
      <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_minmax(18rem,0.9fr)_11rem] lg:items-center">
        <div>
          <p className="text-base font-semibold text-[var(--dash-text)]">
            Maria Santos - move-out cleaning
          </p>
          <p className="mt-2 text-sm leading-6 text-[var(--dash-text-secondary)]">
            2-bedroom apartment, downtown. Wants help before Friday. Missing
            preferred arrival window.
          </p>
        </div>
        <div className="rounded-[14px] border border-[var(--dash-border)] bg-[var(--dash-surface-elevated)] p-3 text-sm leading-6 text-[var(--dash-text-secondary)]">
          <span className="font-semibold text-[var(--dash-text)]">Next action:</span> Ask
          for the time window, then copy a concise owner-reviewed reply.
        </div>
        <div className="grid gap-2 sm:grid-cols-2 lg:w-44 lg:grid-cols-1">
          <CopyButton label="Copy quote link" value={quotePath} />
          <Link className={buttonClass} href="/dashboard/configuration">
            Check setup
          </Link>
        </div>
      </div>
      <p className="text-sm leading-6 text-[var(--dash-text-secondary)]">
        This sample is not stored as customer data. It shows the workflow until
        real quote requests arrive.
      </p>
    </div>
  );
}

function LeadMobileCard({ item }: Readonly<{ item: LeadDeskItem }>) {
  return (
    <Link
      className="grid gap-3 border-b border-[var(--dash-border)] p-3 text-[13px] transition last:border-b-0 hover:bg-[var(--dash-primary-soft)] xl:hidden"
      href={`/dashboard/leads/${item.lead.id}`}
    >
      <div className="flex items-start justify-between gap-3">
        <span className="min-w-0">
          <span className="block truncate font-semibold text-[var(--dash-text)]">
            {item.lead.customer_name ?? "Unnamed lead"}
          </span>
          <span className="mt-1 block break-all text-[13px] leading-5 text-[var(--dash-text-muted)]">
            {item.lead.customer_contact ?? "No contact captured"}
          </span>
        </span>
        <LeadStatusBadge value={item.lead.status} />
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        <span className="rounded-[12px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] p-2">
          <span className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-[var(--dash-text-muted)]">Service</span>
          <span className="mt-1 block text-[var(--dash-text)]">{item.lead.service_type ?? "Service not set"}</span>
        </span>
        <span className="rounded-[12px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] p-2">
          <span className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-[var(--dash-text-muted)]">Location</span>
          <span className="mt-1 block text-[var(--dash-text)]">{item.lead.city_or_service_area ?? "Area missing"}</span>
        </span>
      </div>
      <div className="flex flex-wrap gap-2">
        <LeadQualityBadge value={item.score.quality_level} />
        <ResponseSlaBadge value={item.lead.response_sla_state} />
      </div>
      <p className="rounded-[12px] bg-[var(--dash-primary-soft)] px-3 py-2 text-[13px] leading-5 text-[var(--dash-text)]">
        <span className="font-semibold">Next action:</span> {item.recommendedAction}
      </p>
    </Link>
  );
}

export function LeadWorkspaceQueue({
  leads,
  quotePath,
}: LeadWorkspaceQueueProps) {
  const [activeFilter, setActiveFilter] = useState<LeadFilter>("all");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<LeadSort>("most_urgent");
  const hasActiveFilter = activeFilter !== "all" || search.trim().length > 0;
  const filteredLeads = useMemo(
    () =>
      sortLeads(
        leads.filter(
          (item) => matchesFilter(item, activeFilter) && matchesSearch(item, search),
        ),
        sort,
      ),
    [activeFilter, leads, search, sort],
  );

  function clearFilters() {
    setActiveFilter("all");
    setSearch("");
    setSort("most_urgent");
  }

  return (
    <>
      <div className="mt-3 grid gap-3">
        <div className="flex gap-1 overflow-x-auto rounded-[14px] bg-[var(--dash-surface-muted)] p-1">
          {filters.map((filter) => (
            <button
              className={
                activeFilter === filter.value
                  ? "inline-flex h-9 shrink-0 items-center rounded-[10px] bg-[var(--dash-primary)] px-3 text-xs font-semibold text-[#03130c]"
                  : "inline-flex h-9 shrink-0 items-center rounded-[10px] px-3 text-xs font-semibold text-[var(--dash-text-secondary)] transition hover:bg-[var(--dash-primary-soft)] hover:text-[var(--dash-text)]"
              }
              key={filter.value}
              onClick={() => setActiveFilter(filter.value)}
              type="button"
            >
              {filter.label}
            </button>
          ))}
        </div>

        <div className="flex w-full flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
          <input
            className={`${inputClass} lg:max-w-md`}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search name, contact, service, area"
            type="search"
            value={search}
          />
          <div className="flex flex-col gap-2 sm:flex-row">
            <select
              className={`${inputClass} sm:w-44`}
              onChange={(event) => setSort(event.target.value as LeadSort)}
              value={sort}
            >
              <option value="most_urgent">Most urgent</option>
              <option value="newest">Newest</option>
              <option value="oldest">Oldest</option>
            </select>
            {hasActiveFilter || sort !== "most_urgent" ? (
              <button className={buttonClass} onClick={clearFilters} type="button">
                Clear
              </button>
            ) : null}
          </div>
        </div>
      </div>

      <div className="mt-3 min-w-0 overflow-hidden rounded-[16px] border border-[var(--dash-border)]">
        <div className="hidden min-w-[1180px] grid-cols-[minmax(210px,1.15fr)_130px_130px_110px_120px_130px_minmax(220px,1fr)_130px] border-b border-[var(--dash-border)] bg-[var(--dash-surface-muted)] px-3.5 py-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-[var(--dash-text-muted)] xl:grid">
          <span>Customer</span>
          <span>Service</span>
          <span>Location</span>
          <span>Quality</span>
          <span>SLA</span>
          <span>Status</span>
          <span>Next action</span>
          <span>Created</span>
        </div>

        {filteredLeads.length > 0 ? (
          <>
            <div className="xl:hidden">
              {filteredLeads.map((item) => (
                <LeadMobileCard item={item} key={item.lead.id} />
              ))}
            </div>
            <div className="hidden overflow-x-auto xl:block">
              {filteredLeads.map((item) => (
                <Link
                  className="grid min-h-[68px] min-w-[1180px] grid-cols-[minmax(210px,1.15fr)_130px_130px_110px_120px_130px_minmax(220px,1fr)_130px] items-center gap-3 border-b border-[var(--dash-border)] px-3.5 py-2.5 text-[13px] transition last:border-b-0 hover:bg-[var(--dash-primary-soft)]"
                  href={`/dashboard/leads/${item.lead.id}`}
                  key={item.lead.id}
                >
                  <span className="min-w-0">
                    <span className="block truncate font-semibold text-[var(--dash-text)]">
                      {item.lead.customer_name ?? "Unnamed lead"}
                    </span>
                    <span className="mt-1 block break-all text-[13px] leading-5 text-[var(--dash-text-muted)]">
                      {item.lead.customer_contact ?? "No contact captured"}
                    </span>
                  </span>
                  <span className="text-[var(--dash-text-secondary)]">
                    {item.lead.service_type ?? "Service not set"}
                  </span>
                  <span className="text-[var(--dash-text-secondary)]">
                    {item.lead.city_or_service_area ?? "Area missing"}
                  </span>
                  <LeadQualityBadge value={item.score.quality_level} />
                  <ResponseSlaBadge value={item.lead.response_sla_state} />
                  <LeadStatusBadge value={item.lead.status} />
                  <span>
                    <span className="inline-flex rounded-[9px] bg-[var(--dash-primary-soft)] px-2.5 py-1 text-xs font-semibold text-[var(--dash-text)]">
                      {item.recommendedAction}
                    </span>
                    <span className="mt-1 block text-[13px] leading-5 text-[var(--dash-text-muted)]">
                      {item.primaryIssue}
                    </span>
                  </span>
                  <span className="text-[13px] leading-5 text-[var(--dash-text-muted)]">
                    {formatDate(item.lead.created_at)}
                  </span>
                </Link>
              ))}
            </div>
          </>
        ) : (
          <div className="p-4">
            {leads.length === 0 ? (
              <SampleLeadEmptyState quotePath={quotePath} />
            ) : (
              <EmptyState
                action={
                  hasActiveFilter ? (
                    <button className={buttonClass} onClick={clearFilters} type="button">
                      Clear filters
                    </button>
                  ) : undefined
                }
                title="No leads found."
              >
                Try another search, clear filters, or sort by newest quote requests.
              </EmptyState>
            )}
          </div>
        )}
      </div>
    </>
  );
}
