/**
 * ============================================================
 * File: components/dashboard/configuration-tabs.tsx
 * Project: BizPilot AI
 * Description: Provides section navigation for the business configuration workspace.
 * Role: Keeps every configuration section visible and reachable for Phase 18A manual QA.
 * Related:
 * - app/(dashboard)/dashboard/configuration/page.tsx
 * - server/actions/business-configuration.actions.ts
 * Author: MoOoH
 * Created: 2026-05-16
 * Last Updated: 2026-05-18
 * Change Log:
 * - 2026-05-16: Created mounted tab panels so the parent form receives every required input on submit.
 * - 2026-05-18: Finalized sticky anchor tabs with theme-safe styling and mobile overflow.
 * ============================================================
 */

import type { ReactElement, ReactNode } from "react";
import { Children, isValidElement } from "react";

type Section = Readonly<{ id: string; label: string }>;
type Props = Readonly<{ children: ReactNode; sections: Section[] }>;

function panelId(panel: ReactElement): string | undefined {
  return (panel as ReactElement<{ id?: string }>).props.id;
}

export function ConfigurationTabs({ children, sections }: Props) {
  const panels = Children.toArray(children).filter(isValidElement);

  return (
    <div className="space-y-3">
      <nav
        aria-label="Quote setup sections"
        className="sticky top-[72px] z-10 rounded-[16px] border border-[var(--dash-border)] bg-[var(--dash-surface-elevated)]/95 p-2 shadow-sm backdrop-blur"
      >
        <div className="flex gap-1 overflow-x-auto pb-0.5">
          {sections.map((section) => (
            <a
              className="inline-flex h-9 shrink-0 items-center rounded-[11px] px-3 text-xs font-semibold text-[var(--dash-text-secondary)] transition hover:bg-[var(--dash-primary-soft)] hover:text-[var(--dash-text)]"
              href={`#${section.id}`}
              key={section.id}
            >
              {section.label}
            </a>
          ))}
        </div>
      </nav>

      {panels.map((panel, index) => (
        <div key={panelId(panel) ?? index}>{panel}</div>
      ))}
    </div>
  );
}
