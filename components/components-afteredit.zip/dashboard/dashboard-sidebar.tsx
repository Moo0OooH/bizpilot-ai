"use client";

/**
 * ============================================================
 * File: components/dashboard/dashboard-sidebar.tsx
 * Project: BizPilot AI
 * Description: Renders the shared protected dashboard sidebar navigation.
 * Role: Provides route-aware app navigation for protected dashboard pages.
 * Related:
 * - components/dashboard/dashboard-shell.tsx
 * - app/(dashboard)/layout.tsx
 * Author: MoOoH
 * Created: 2026-05-10
 * Last Updated: 2026-05-18
 * Change Log:
 * - 2026-05-10: Created reusable dashboard sidebar shell component.
 * - 2026-05-17: Tuned navigation for calm quote recovery positioning.
 * - 2026-05-18: Finalized Phase 18A navigation: Overview, Leads, Quote Setup, Business Profile, Settings.
 * ============================================================
 */

import Link from "next/link";
import { usePathname } from "next/navigation";

type DashboardSidebarProps = Readonly<{
  activeBusinessName: string;
  userLabel: string;
}>;

type NavigationItem = Readonly<{
  href: string;
  icon: string;
  label: string;
  match?: (pathname: string) => boolean;
}>;

type NavigationGroup = Readonly<{
  items: NavigationItem[];
  label: string;
}>;

const navigationGroups: NavigationGroup[] = [
  {
    label: "Command center",
    items: [
      {
        href: "/dashboard",
        icon: "O",
        label: "Overview",
        match: (pathname) => pathname === "/dashboard",
      },
      {
        href: "/dashboard/leads",
        icon: "L",
        label: "Leads",
        match: (pathname) => pathname.startsWith("/dashboard/leads"),
      },
    ],
  },
  {
    label: "Setup",
    items: [
      {
        href: "/dashboard/configuration",
        icon: "Q",
        label: "Quote Setup",
        match: (pathname) => pathname === "/dashboard/configuration",
      },
      {
        href: "/dashboard/business-profile",
        icon: "B",
        label: "Business Profile",
        match: (pathname) => pathname === "/dashboard/business-profile",
      },
      {
        href: "/dashboard/settings",
        icon: "S",
        label: "Settings",
        match: (pathname) => pathname === "/dashboard/settings",
      },
    ],
  },
];

const mobileNavigation: NavigationItem[] = navigationGroups.flatMap(
  (group) => group.items,
);

function navClass(isActive: boolean): string {
  if (isActive) {
    return "flex h-10 items-center gap-2.5 rounded-[12px] border border-[#17D492]/20 bg-[#17D492]/14 px-3 font-semibold text-white shadow-[0_10px_26px_rgba(23,212,146,0.07)]";
  }

  return "flex h-10 items-center gap-2.5 rounded-[12px] px-3 text-white/62 transition hover:bg-[#17D492]/8 hover:text-white";
}

function NavIcon({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-[8px] border border-current/15 text-[12px] font-semibold">
      {children}
    </span>
  );
}

function MobileNavLink({ item, pathname }: Readonly<{ item: NavigationItem; pathname: string }>) {
  const isActive = item.match?.(pathname) ?? pathname === item.href;

  return (
    <Link
      className={
        isActive
          ? "flex min-w-0 flex-1 flex-col items-center justify-center gap-1 rounded-[12px] bg-[#17D492]/14 px-2 py-1.5 text-[#17D492]"
          : "flex min-w-0 flex-1 flex-col items-center justify-center gap-1 rounded-[12px] px-2 py-1.5 text-white/58"
      }
      href={item.href}
    >
      <span className="text-[11px] font-bold">{item.icon}</span>
      <span className="max-w-full truncate text-[10px] font-semibold">{item.label}</span>
    </Link>
  );
}

export function DashboardSidebar({
  activeBusinessName,
  userLabel,
}: DashboardSidebarProps) {
  const pathname = usePathname();

  return (
    <>
      <aside className="dashboard-sidebar sticky top-0 hidden h-screen w-[260px] border-r text-white lg:flex lg:flex-col">
        <div className="border-b border-white/10 px-5 py-4">
          <p className="text-lg font-semibold tracking-[-0.02em] text-white">
            BizPilot
          </p>
          <p className="mt-1.5 truncate text-[13px] text-white/58">
            Quote Recovery Command Center
          </p>
        </div>

        <nav className="flex-1 space-y-5 overflow-y-auto px-3.5 py-5 text-[13px]">
          {navigationGroups.map((group) => (
            <div key={group.label}>
              <p className="px-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-white/38">
                {group.label}
              </p>
              <div className="mt-2 grid gap-1">
                {group.items.map((item) => {
                  const isActive = item.match?.(pathname) ?? pathname === item.href;

                  return (
                    <Link className={navClass(isActive)} href={item.href} key={item.label}>
                      <NavIcon>{item.icon}</NavIcon>
                      <span className="truncate">{item.label}</span>
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="space-y-3 border-t border-white/10 p-3 text-[13px]">
          <div className="rounded-[14px] border border-white/[0.08] bg-white/[0.03] p-3">
            <div className="flex items-center justify-between gap-3">
              <p className="truncate font-semibold text-white">Quote link</p>
              <span className="rounded-full border border-[#17D492]/20 bg-[#17D492]/12 px-2 py-0.5 text-[11px] font-semibold text-[#17D492]">
                Active
              </span>
            </div>
            <p className="mt-1.5 text-[12px] leading-4 text-white/52">
              Keep this ready before every pilot call.
            </p>
          </div>

          <div className="rounded-[14px] border border-white/[0.08] bg-white/[0.03] p-3">
            <p className="truncate font-semibold text-white">{activeBusinessName}</p>
            <p className="mt-1.5 text-[12px] text-white/42">Signed in as</p>
            <p className="mt-0.5 break-words text-[12px] text-white/68">{userLabel}</p>
          </div>
        </div>
      </aside>

      <nav className="dashboard-mobile-nav fixed inset-x-0 bottom-0 z-30 border-t border-white/10 bg-[#071018]/95 px-2 py-2 shadow-[0_-18px_40px_rgba(0,0,0,0.28)] backdrop-blur lg:hidden">
        <div className="mx-auto flex max-w-xl gap-1">
          {mobileNavigation.map((item) => (
            <MobileNavLink item={item} key={item.href} pathname={pathname} />
          ))}
        </div>
      </nav>
    </>
  );
}
