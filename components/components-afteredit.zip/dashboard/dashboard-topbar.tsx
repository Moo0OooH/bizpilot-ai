/**
 * ============================================================
 * File: components/dashboard/dashboard-topbar.tsx
 * Project: BizPilot AI
 * Description: Renders the protected workspace topbar.
 * Role: Provides workspace context, search affordance, quick quote-link actions, and user controls.
 * Related:
 * - components/dashboard/dashboard-shell.tsx
 * - server/actions/auth.actions.ts
 * Author: MoOoH
 * Created: 2026-05-10
 * Last Updated: 2026-05-18
 * Change Log:
 * - 2026-05-10: Added SaaS workspace topbar.
 * - 2026-05-17: Tuned actions for owner attention and quote recovery.
 * - 2026-05-17: Added a persisted dashboard light/dark theme selector.
 * - 2026-05-18: Finalized Phase 18A topbar around Copy Quote Link, Preview Quote Page, and owner review flow.
 * ============================================================
 */

import Link from "next/link";

import { signOutAction } from "@/server/actions/auth.actions";

import { CopyButton } from "./copy-button";
import { DashboardThemeSelector } from "./dashboard-theme";
import { buttonClass, primaryButtonClass } from "./dashboard-ui";

type DashboardTopbarProps = Readonly<{
  activeBusinessName: string;
  businessSlug: string;
  userLabel: string;
}>;

export function DashboardTopbar({
  activeBusinessName,
  businessSlug,
  userLabel,
}: DashboardTopbarProps) {
  const quotePath = `/quote/${businessSlug}`;

  return (
    <header className="dashboard-topbar sticky top-0 z-20 border-b backdrop-blur">
      <div className="flex min-h-[64px] items-center gap-2.5 px-4 py-2 sm:px-5 md:px-6 lg:px-8 2xl:px-10">
        <Link
          className="dashboard-business-switcher inline-flex h-10 w-[155px] min-w-0 items-center gap-2.5 rounded-[12px] border px-3 text-[13px] font-semibold shadow-sm sm:w-[220px]"
          href="/dashboard"
        >
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-[9px] bg-[var(--dash-primary)] text-[12px] font-bold text-[#03130c]">
            BP
          </span>
          <span className="min-w-0">
            <span className="block truncate leading-4">{activeBusinessName}</span>
            <span className="hidden truncate text-[11px] font-medium text-[var(--dash-text-muted)] sm:block">
              Quote recovery desk
            </span>
          </span>
        </Link>

        <div className="dashboard-topbar-search hidden h-10 min-w-0 max-w-[560px] flex-1 items-center rounded-[12px] border px-3.5 text-[13px] md:flex">
          Search leads, follow-ups, quote requests...
          <span className="ml-auto rounded-md border border-[var(--dash-border-strong)] bg-white/[0.04] px-1.5 py-0.5 text-xs text-[var(--dash-text-muted)]">
            /
          </span>
        </div>

        <div className="ml-auto flex items-center gap-2">
          <DashboardThemeSelector />
          <CopyButton className="hidden lg:inline-flex" label="Copy Quote Link" value={quotePath} />
          <Link className={`${buttonClass} hidden sm:inline-flex`} href={quotePath}>
            Preview Quote Page
          </Link>
          <Link className={primaryButtonClass} href="/dashboard/leads">
            Review Leads
          </Link>
          <form action={signOutAction}>
            <button
              className="biz-button-secondary inline-flex h-9 max-w-[5.5rem] items-center justify-center rounded-[11px] border px-3 text-[13px] font-semibold shadow-sm sm:max-w-[8rem]"
              title={userLabel}
              type="submit"
            >
              <span className="truncate">Sign out</span>
            </button>
          </form>
        </div>
      </div>
    </header>
  );
}
