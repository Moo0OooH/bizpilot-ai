/**
 * ============================================================
 * File: components/dashboard/dashboard-ui.tsx
 * Project: BizPilot AI
 * Description: Shared dashboard UI primitives for the protected SaaS workspace.
 * Role: Provides reusable cards, headers, metrics, badges, rails, actions, and empty states.
 * Related:
 * - components/dashboard/dashboard-shell.tsx
 * - app/(dashboard)/dashboard/page.tsx
 * Author: MoOoH
 * Created: 2026-05-10
 * Last Updated: 2026-05-18
 * Change Log:
 * - 2026-05-10: Added reusable SaaS dashboard presentation primitives.
 * - 2026-05-11: Expanded primitives for a production-grade quote recovery cockpit.
 * - 2026-05-17: Tuned primitives for calm dark operational dashboard surfaces.
 * - 2026-05-18: Finalized Phase 18A command-center primitives, responsive density, and theme-safe color usage.
 * ============================================================
 */

import Link from "next/link";

export type CardVariant = "default" | "elevated" | "muted" | "priority";
export type Tone = "amber" | "blue" | "emerald" | "neutral" | "red";

type CardProps = Readonly<{
  children: React.ReactNode;
  className?: string;
  variant?: CardVariant;
}>;

type PageHeaderProps = Readonly<{
  actions?: React.ReactNode;
  description: string;
  eyebrow?: string;
  title: string;
}>;

type SectionHeaderProps = Readonly<{
  action?: React.ReactNode;
  description?: string;
  title: string;
}>;

type KpiCardProps = Readonly<{
  detail?: string;
  label: string;
  value: string | number;
}>;

type MetricCardProps = Readonly<{
  cta?: React.ReactNode;
  detail?: string;
  label: string;
  tone?: Tone;
  value: string | number;
}>;

type StatusBadgeProps = Readonly<{
  children: React.ReactNode;
  tone?: Tone;
}>;

type TabLinkProps = Readonly<{
  active?: boolean;
  children: React.ReactNode;
  href: string;
}>;

type EmptyStateProps = Readonly<{
  action?: React.ReactNode;
  children: React.ReactNode;
  title: string;
}>;

export const buttonClass =
  "biz-button-secondary inline-flex min-h-9 items-center justify-center rounded-[11px] border px-3.5 py-2 text-[13px] font-semibold leading-none shadow-sm transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--dash-primary)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--dash-bg)]";

export const primaryButtonClass =
  "biz-button-primary inline-flex min-h-9 items-center justify-center rounded-[11px] px-3.5 py-2 text-[13px] font-semibold leading-none shadow-sm transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--dash-primary)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--dash-bg)]";

export const ghostButtonClass =
  "biz-button-ghost inline-flex min-h-9 items-center justify-center rounded-[11px] px-3.5 py-2 text-[13px] font-semibold leading-none transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--dash-primary)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--dash-bg)]";

export const disabledButtonClass =
  "inline-flex min-h-9 cursor-not-allowed items-center justify-center rounded-[11px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] px-3.5 py-2 text-[13px] font-semibold leading-none text-[var(--dash-text-muted)]";

export const inputClass =
  "biz-field min-h-10 w-full rounded-[12px] border px-3.5 py-2 text-sm outline-none transition placeholder:text-[var(--dash-text-muted)] focus-visible:ring-2 focus-visible:ring-[var(--dash-primary)]/25";

export const textareaClass =
  "biz-field w-full rounded-[12px] border px-3.5 py-2.5 text-sm leading-6 outline-none transition placeholder:text-[var(--dash-text-muted)] focus-visible:ring-2 focus-visible:ring-[var(--dash-primary)]/25";

export const labelClass =
  "grid gap-1.5 text-sm font-medium text-[var(--dash-text)]";

const toneClasses: Record<Tone, string> = {
  amber: "border-amber-300/35 bg-amber-500/12 text-amber-700 dark:text-amber-200",
  blue: "border-sky-300/35 bg-sky-500/12 text-sky-700 dark:text-sky-200",
  emerald:
    "border-emerald-300/35 bg-emerald-500/12 text-emerald-700 dark:text-emerald-200",
  neutral:
    "border-[var(--dash-border-strong)] bg-[var(--dash-surface-muted)] text-[var(--dash-text-secondary)]",
  red: "border-red-300/35 bg-red-500/12 text-red-700 dark:text-red-200",
};

function humanize(value: string): string {
  return value.replaceAll("_", " ");
}

function cardClass(variant: CardVariant): string {
  const variants: Record<CardVariant, string> = {
    default: "biz-card",
    elevated: "biz-card biz-card-elevated",
    muted: "biz-card-muted",
    priority: "biz-card-priority",
  };

  return variants[variant];
}

export function DashboardCard({
  children,
  className = "",
  variant = "default",
}: CardProps) {
  return (
    <section
      className={`min-w-0 rounded-[18px] border ${cardClass(variant)} ${className}`}
    >
      {children}
    </section>
  );
}

export function PageHeader({
  actions,
  description,
  eyebrow,
  title,
}: PageHeaderProps) {
  return (
    <header className="flex flex-col gap-3 border-b border-[var(--dash-border)] pb-4 md:flex-row md:items-start md:justify-between">
      <div className="min-w-0">
        {eyebrow ? (
          <p className="text-[12px] font-semibold uppercase tracking-[0.16em] text-[var(--dash-text-muted)]">
            {eyebrow}
          </p>
        ) : null}
        <h1 className="mt-1.5 text-[28px] font-semibold leading-[1.12] tracking-[-0.02em] text-[var(--dash-text)] sm:text-[30px]">
          {title}
        </h1>
        <p className="mt-1.5 max-w-3xl text-[14px] leading-6 text-[var(--dash-text-secondary)]">
          {description}
        </p>
      </div>
      {actions ? (
        <div className="flex shrink-0 flex-wrap gap-2 md:justify-end">{actions}</div>
      ) : null}
    </header>
  );
}

export function SectionHeader({
  action,
  description,
  title,
}: SectionHeaderProps) {
  return (
    <div className="flex items-start justify-between gap-3">
      <div className="min-w-0">
        <h2 className="text-[15px] font-semibold leading-5 text-[var(--dash-text)]">
          {title}
        </h2>
        {description ? (
          <p className="mt-1 text-[13px] leading-5 text-[var(--dash-text-secondary)]">
            {description}
          </p>
        ) : null}
      </div>
      {action ? <div className="shrink-0">{action}</div> : null}
    </div>
  );
}

export function MetricCard({
  cta,
  detail,
  label,
  tone = "neutral",
  value,
}: MetricCardProps) {
  const accentClass: Record<Tone, string> = {
    amber: "text-amber-600 dark:text-amber-300",
    blue: "text-sky-600 dark:text-sky-300",
    emerald: "text-emerald-600 dark:text-emerald-300",
    neutral: "text-[var(--dash-text)]",
    red: "text-red-600 dark:text-red-300",
  };

  return (
    <DashboardCard className="flex min-h-[132px] flex-col p-4">
      <div className="flex items-start justify-between gap-3">
        <p className="text-[13px] font-medium text-[var(--dash-text-muted)]">
          {label}
        </p>
        <span className={`h-2 w-2 rounded-full ${toneClasses[tone]}`} />
      </div>
      <p className={`mt-2 text-[28px] font-semibold leading-none ${accentClass[tone]}`}>
        {value}
      </p>
      {detail ? (
        <p className="mt-2 text-[13px] leading-5 text-[var(--dash-text-secondary)]">
          {detail}
        </p>
      ) : null}
      {cta ? <div className="mt-auto pt-3">{cta}</div> : null}
    </DashboardCard>
  );
}

export function KpiCard({ detail, label, value }: KpiCardProps) {
  return (
    <MetricCard
      label={label}
      value={value}
      {...(detail ? { detail } : {})}
    />
  );
}

export function StatusBadge({ children, tone = "neutral" }: StatusBadgeProps) {
  return (
    <span
      className={`inline-flex min-h-6 max-w-full items-center justify-center rounded-full border px-2.5 py-1 text-xs font-semibold capitalize leading-none ${toneClasses[tone]}`}
    >
      <span className="truncate">{children}</span>
    </span>
  );
}

export function LeadQualityBadge({ value }: Readonly<{ value: string }>) {
  const tone: Tone =
    value === "strong"
      ? "emerald"
      : value === "good"
        ? "blue"
        : value === "needs_info"
          ? "amber"
          : "red";

  return <StatusBadge tone={tone}>{humanize(value)}</StatusBadge>;
}

export function ResponseSlaBadge({ value }: Readonly<{ value: string }>) {
  const tone: Tone =
    value === "overdue"
      ? "red"
      : value.includes("follow")
        ? "amber"
        : value.includes("copied") || value.includes("replied")
          ? "emerald"
          : value.includes("new") || value.includes("viewed")
            ? "blue"
            : "neutral";

  return <StatusBadge tone={tone}>{humanize(value)}</StatusBadge>;
}

export function LeadStatusBadge({ value }: Readonly<{ value: string }>) {
  const tone: Tone =
    value === "lost" || value === "archived"
      ? "red"
      : value === "booked" || value === "replied"
        ? "emerald"
        : value === "follow_up_needed"
          ? "amber"
          : value === "new" || value === "reviewed"
            ? "blue"
            : "neutral";

  return <StatusBadge tone={tone}>{humanize(value)}</StatusBadge>;
}

export function TabLink({ active = false, children, href }: TabLinkProps) {
  return (
    <Link
      className={
        active
          ? "inline-flex min-h-9 items-center rounded-[10px] bg-[var(--dash-primary)] px-3 text-xs font-semibold text-[#03130c]"
          : "inline-flex min-h-9 items-center rounded-[10px] px-3 text-sm font-semibold text-[var(--dash-text-secondary)] transition hover:bg-[var(--dash-primary-soft)] hover:text-[var(--dash-text)]"
      }
      href={href}
    >
      {children}
    </Link>
  );
}

export function RightRailPanel({
  children,
  className = "",
  variant = "default",
}: CardProps) {
  return (
    <DashboardCard className={`p-3.5 ${className}`} variant={variant}>
      {children}
    </DashboardCard>
  );
}

export function PriorityAction({
  children,
  href,
  label,
  tone = "neutral",
  value,
}: Readonly<{
  children: React.ReactNode;
  href: string;
  label: string;
  tone?: Tone;
  value: string | number;
}>) {
  return (
    <Link
      className={`grid gap-1 rounded-[12px] border px-3 py-2 transition hover:-translate-y-0.5 hover:shadow-sm ${toneClasses[tone]}`}
      href={href}
    >
      <span className="text-[11px] font-semibold uppercase tracking-[0.14em]">
        {label}
      </span>
      <span className="flex items-center justify-between gap-3">
        <span className="text-sm font-semibold">{children}</span>
        <span className="text-lg font-semibold">{value}</span>
      </span>
    </Link>
  );
}

export function QuickActionTile({
  children,
  description,
  disabled = false,
  href,
  icon,
  title,
}: Readonly<{
  children?: React.ReactNode;
  description?: string;
  disabled?: boolean;
  href?: string;
  icon?: string;
  title?: string;
}>) {
  const className =
    "flex min-h-16 items-center gap-3 rounded-[15px] border border-[var(--dash-border)] bg-[var(--dash-surface-muted)] px-4 py-3 text-left transition";

  const content = title ? (
    <>
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[12px] bg-[var(--dash-primary-soft)] text-sm font-semibold text-[var(--dash-primary)]">
        {icon ?? "A"}
      </span>
      <span className="min-w-0">
        <span className="block truncate text-sm font-semibold text-[var(--dash-text)]">
          {title}
        </span>
        {description ? (
          <span className="mt-0.5 block text-[12px] leading-4 text-[var(--dash-text-secondary)]">
            {description}
          </span>
        ) : null}
      </span>
      {children ? <span className="ml-auto shrink-0">{children}</span> : null}
    </>
  ) : (
    children
  );

  if (disabled || !href) {
    return (
      <div className={`${className} opacity-65`} aria-disabled="true">
        {content}
      </div>
    );
  }

  return (
    <Link className={`${className} hover:border-[rgba(23,212,146,0.28)] hover:bg-[var(--dash-primary-soft)]`} href={href}>
      {content}
    </Link>
  );
}

export function EmptyState({ action, children, title }: EmptyStateProps) {
  return (
    <div className="rounded-[16px] border border-dashed border-[var(--dash-border-strong)] bg-[var(--dash-surface-muted)] p-5 text-center">
      <p className="text-sm font-semibold text-[var(--dash-text)]">{title}</p>
      <p className="mx-auto mt-1 max-w-xl text-[13px] leading-5 text-[var(--dash-text-secondary)]">
        {children}
      </p>
      {action ? <div className="mt-4 flex justify-center">{action}</div> : null}
    </div>
  );
}
