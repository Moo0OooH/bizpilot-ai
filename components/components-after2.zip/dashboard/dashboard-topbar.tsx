/**
 * ============================================================
 * File: components/dashboard/dashboard-topbar.tsx
 * Project: BizPilot AI
 * Description: Renders the protected workspace topbar.
 * Role: Provides workspace context, quote-link actions, lead review actions, and user controls.
 * Related:
 * - components/dashboard/dashboard-shell.tsx
 * - server/actions/auth.actions.ts
 * Author: MoOoH
 * Created: 2026-05-10
 * Last Updated: 2026-05-18
 * Change Log:
 * - 2026-05-10: Added SaaS workspace topbar.
 * - 2026-05-17: Tuned actions for owner attention and quote recovery.
 * - 2026-05-17: Added a persisted dashboard light/dark theme selector.
 * - 2026-05-18: Finalized Phase 18A topbar around Copy Quote Link, Preview Quote Page, and owner review flow.
 * - 2026-05-18: Removed overcrowded global search from topbar; search now lives inside operational pages.
 * ============================================================
 */

import Link from "next/link";

import { signOutAction } from "@/server/actions/auth.actions";

import { CopyButton } from "./copy-button";
import { DashboardThemeSelector } from "./dashboard-theme";
import { buttonClass, primaryButtonClass } from "./dashboard-ui";

type DashboardTopbarProps = Readonly<{
  activeBusinessName: string;
  businessSlug: string;
  userLabel: string;
}>;

export function DashboardTopbar({
  activeBusinessName,
  businessSlug,
  userLabel,
}: DashboardTopbarProps) {
  const quotePath = `/quote/${businessSlug}`;

  return (
    <header className="dashboard-topbar sticky top-0 z-20 border-b backdrop-blur">
      <div className="flex min-h-[68px] min-w-0 items-center gap-3 px-4 py-2 sm:px-5 md:px-6 lg:px-8 2xl:px-10">
        <Link
          className="dashboard-business-switcher inline-flex h-11 w-[170px] min-w-0 shrink-0 items-center gap-2.5 rounded-[14px] border px-3 text-[13px] font-semibold shadow-sm sm:w-[240px]"
          href="/dashboard"
        >
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px] bg-[var(--dash-primary)] text-[12px] font-bold text-[#03130c]">
            BP
          </span>
          <span className="min-w-0">
            <span className="block truncate leading-4">{activeBusinessName}</span>
            <span className="hidden truncate text-[11px] font-medium text-[var(--dash-text-muted)] sm:block">
              Quote recovery desk
            </span>
          </span>
        </Link>

        <div className="min-w-0 flex-1" aria-hidden="true" />

        <div className="flex min-w-0 shrink-0 items-center justify-end gap-2">
          <DashboardThemeSelector />
          <CopyButton className="hidden md:inline-flex" label="Copy Quote Link" value={quotePath} />
          <Link className={`${buttonClass} hidden lg:inline-flex`} href={quotePath}>
            Preview Quote Page
          </Link>
          <Link className={`${primaryButtonClass} hidden sm:inline-flex`} href="/dashboard/leads">
            Review Leads
          </Link>
          <form action={signOutAction}>
            <button
              className="biz-button-secondary inline-flex h-10 max-w-[5.5rem] items-center justify-center rounded-[12px] border px-3 text-[13px] font-semibold shadow-sm sm:max-w-[8rem]"
              title={userLabel}
              type="submit"
            >
              <span className="truncate">Sign out</span>
            </button>
          </form>
        </div>
      </div>
    </header>
  );
}
